#include <iostream>
#include <algorithm>
#include <cassert>
#include <map>

using namespace std;

bool posortowana(int [], int, int);
bool bijekcja(int [], int [], int [], int, int);
bool maksimum(int [], int, int);

int selection_sort(int tab[], int n){
	int i;
	int k;
	int tab_sort[n];
	const int N = n;
	int TAB_POCZATK[n];
	for(int i = 0; i < n; ++i)//Kopiowanie tablicy pocz�tkowej do TAB_POCZATK
        TAB_POCZATK[i] = tab[i];
	assert(posortowana(tab_sort, N, N) && bijekcja(TAB_POCZATK, tab, tab_sort, N, N));
	assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N));
	while(n>0){
        /* zbie�nik while */ assert(n > 0);
        /* zbie�nik while */ assert(n > n-1);
        /* zbie�nik while */ int ZN = n;
        /* zbie�nik while */ assert(ZN > n-1);
        assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0);
		assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, 0, 0));
		i = 0;
		/* zbie�nik while */ assert(ZN > n-1);
		assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, 0));
		for(k=1; k<n; ++k){//{k=1;}: assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, k-1));
            /* zbie�nik while */ assert(ZN > n-1);
            /* zbie�nik for */ assert(n-k > 0);
            /* zbie�nik for */ int ZK = n-k;
            /* zbie�nik for */ assert(ZK > n-(k+1));
            assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, k-1) && k<n);
			if(tab[i]<tab[k]){
			    /* zbie�nik while */ assert(ZN > n-1);
			    /* zbie�nik for */ assert(ZK > n-(k+1));
                int I = i;
                assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, k-1) && k<n && tab[i]<tab[k]);
                assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, I, k-1) && k<n && tab[I]<tab[k]);
				i=k;
                /* zbie�nik while */ assert(ZN > n-1);
                /* zbie�nik for */ assert(ZK > n-(k+1));
                assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, I, k-1) && k<n && tab[I]<tab[k] && i==k);
                assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, I, k-1) && k<n && tab[i]>=tab[k]);
                assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, k) && k<n);
			}
			/* zbie�nik while */ assert(ZN > n-1);
			/* zbie�nik for */ assert(ZK > n-(k+1));
			assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, k) && k<n && tab[i]>=tab[k]);
            assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, k) && k<n);
            //{++k;}: assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, k-1) && k<=n);
            // zbie�nik for po {++k;}: assert(ZK > n-k);
		}
		/* zbie�nik while */ assert(ZN > n-1);
		assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>0 && maksimum(tab, i, k-1) && k>=n);
		assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && maksimum(tab, i, k-1) && n>0);
		/* zbie�nik while */ assert(ZN > n-1);
		--n;
		/* zbie�nik while */ assert(ZN > n);
		assert(posortowana(tab_sort, n+1, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n+1, N) && maksimum(tab, i, k-1) && n>=0);
		tab_sort[n]=tab[i];
		/* zbie�nik while */ assert(ZN > n);
		assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n+1, N) && maksimum(tab, i, k-1) && n>=0);
		assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n+1, N) && n>=0);
		tab[i]=tab[n];
		/* zbie�nik while */ assert(ZN > n);
		assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n>=0);
	}
	assert(posortowana(tab_sort, n, N) && bijekcja(TAB_POCZATK, tab, tab_sort, n, N) && n<=0);
	assert(posortowana(tab_sort, 0, N) && bijekcja(TAB_POCZATK, tab, tab_sort, 0, N));

}

int main(){
    int tab[] = {423, 342, 56, 35, 2, 24, 645, 67, 35, 24, 13};
    selection_sort(tab, 11);

    return 0;
}

bool posortowana(int tab[], int b, int e){
    for(int i = b+1; i < e; ++i)
        if(tab[i-1]>tab[i]) return false;
    return true;
}

bool bijekcja(int TAB_POCZATK[], int tab1[], int tab2[], int t, int n){
    /*
        Przestawianie element�w o tej samej warto�ci w posortowanym ci�gu
        nie zmienia monotoniczno�ci ci�gu.
        Dla ka�dego elementu z tablicy tab1
        istnieje element o tej samej warto�ci w drugiej tablicy tab2
        oraz ka�dy element z tab1 odpowiada dok�adnie jednemu elementowi tab2
        i element z tab2 odpowiada dok�adnie temu samemu elementowi tab1
    */
    bool is_used[n];
    for(int i = 0; i < n; ++i){
        is_used[i] = false;
    }
    int j;
    int i = 0;
    bool found;
    //I fragment
    for(; i < t; ++i){
        found = false;
        for(j = 0; j < n; ++j){
            if(tab1[i] == TAB_POCZATK[j] && !is_used[j]){
                is_used[j] = true;
                found = true;
                break;
            }
        }
        //Je�elni nie znaleziono odpowiadaj�cego elementu, to bijekcja nie zachodzi
        if(!found){
            return false;
        }
    }
    //II fragment
    for(; i < n; ++i){
        found = false;
        for(j = 0; j < n; ++j){
            if(tab2[i] == TAB_POCZATK[j] && !is_used[j]){
                is_used[j] = true;
                found = true;
                break;
            }
        }
        //Je�elni nie znaleziono odpowiadaj�cego elementu, to bijekcja nie zachodzi
        if(!found){
            return false;
        }
    }
    return true;
}

bool maksimum(int tab[], int i, int k){
    for(int j = 0; j <= k; ++j){
        if(tab[i] < tab[j]) return false;
    }
    return true;
}
